#include "minGlue.h"
#include <string.h>

#if 0
#define INI_FILETYPE    FIL
#define ini_openread(filename,file)   (f_open((file), (filename), FA_READ+FA_OPEN_EXISTING) == FR_OK)
#define ini_openwrite(filename,file)  (f_open((file), (filename), FA_WRITE+FA_CREATE_ALWAYS) == FR_OK)
#define ini_close(file)               (f_close(file) == FR_OK)
#define ini_read(buffer,size,file)    f_gets((buffer), (size), (file))
#define ini_write(buffer,file)        f_puts((buffer), (file))
#define ini_remove(filename)          (f_unlink(filename) == FR_OK)

#define INI_FILEPOS                   DWORD
#define ini_tell(file,pos)            (*(pos) = f_tell((file)))
#define ini_seek(file,pos)            (f_lseek((file), *(pos)) == FR_OK)
#endif

/*  All functions should return zero on failure and a non-zero value on success. */

int ini_openread(const char *filename, INI_FILETYPE *file)
{
	int ret = (f_open((file), (filename), FA_READ+FA_OPEN_EXISTING) == FR_OK);
	return ret;
}

int ini_openwrite(const char *filename, INI_FILETYPE *file)
{
	int ret = (f_open((file), (filename), FA_WRITE+FA_CREATE_ALWAYS) == FR_OK);
	return ret;
}

int ini_close(INI_FILETYPE *file)
{
	int ret = (f_close(file) == FR_OK);
	return ret;
}

// return zero on failure and a non-zero value on success

int ini_read(char *buffer, size_t size, INI_FILETYPE *file)
{
	/* When f_gets fails on any error it returns a null pointer */
	int ret = (f_gets((buffer), (size), (file)) != NULL);
	return ret;
}

int ini_write(char *buffer, INI_FILETYPE *file)
{
	/* When f_puts fails on any error a negative value will be returned */
	int ret = (f_puts((buffer), (file)) >= 0);
	return ret;
}

int ini_rename(const char *source, const char *dest)
{
  /* Function f_rename() does not allow drive letters in the destination file */
  const char *drive = (const char *)strchr(dest, ':');
  drive = (drive == NULL) ? dest : drive + 1;
  return (f_rename(source, drive) == FR_OK);
}

int ini_remove(const char *filename)
{
	int ret = (f_unlink(filename) == FR_OK);
	return ret;
}

int ini_tell(INI_FILETYPE *file, INI_FILEPOS *pos)
{
	return (*(pos) = f_tell((file)));
}

int ini_seek(INI_FILETYPE *file, INI_FILEPOS *pos)
{
	int ret = (f_lseek((file), *(pos)) == FR_OK);
	return ret;
}
