#pragma once

#define INI_BUFFERSIZE  256       /* maximum line length, maximum path length */

/* You must set _USE_STRFUNC to 1 or 2 in the include file ff.h (or tff.h)
 * to enable the "string functions" fgets() and fputs().
 */
#include "ff.h"                   /* include tff.h for Tiny-FatFs */

/* When setting _USE_STRFUNC to 2 (for LF to CR/LF translation), INI_LINETERM
 * should be defined to "\n" (otherwise "\r\n" will be translated by FatFS to
 * "\r\r\n").
*/
#if defined _USE_STRFUNC && _USE_STRFUNC == 2 && !defined INI_LINETERM
  #define INI_LINETERM  "\n"
#endif

#define INI_FILETYPE    FIL
#define INI_FILEPOS     DWORD

int ini_openread(const char *filename, INI_FILETYPE *file);

int ini_openwrite(const char *filename, INI_FILETYPE *file);

int ini_close(INI_FILETYPE *file);
 
int ini_read(char *buffer, size_t size, INI_FILETYPE *file);

int ini_write(char *buffer, INI_FILETYPE *file);

int ini_rename(const char *source, const char *dest);

int ini_remove(const char *filename);

int ini_tell(INI_FILETYPE *file, INI_FILEPOS *pos);

int ini_seek(INI_FILETYPE *file, INI_FILEPOS *pos);